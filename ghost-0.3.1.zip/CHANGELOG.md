# Ghost Changelog

_Showing 14 releases._


## Release 0.3.1-9

* Add invalidate cache headers (_Sebastian Gierlinger_)

## Release 0.3.1-8

No changes were made in this build.


## Release 0.3.1-7

No changes were made in this build.


## Release 0.3.1-6

No changes were made in this build.


## Release 0.3.1-5

No changes were made in this build.


## Release 0.3.1-4

No changes were made in this build.


## Release 0.3.1-3

No changes were made in this build.


## Release 0.3.1-2

No changes were made in this build.


## Release 0.3.1-1

* Bumping build version for post 0.3.0 release (_Hannah Wolfe_)
* Weekly Release 0.3.0-1 (_Hannah Wolfe_)
* Reset version (_Hannah Wolfe_)
* Version bump (_Hannah Wolfe_)
* 0.2.2 version bump for generating pre-releases (_ErisDS_)
* fixing build number after merging package.json from master incorrectly (_ErisDS_)

## Release 0.3.0

* Cleanup (_Hannah Wolfe_)
* Added grunt-contrib-clean task to clear build folder (_nicoburns_)
* Correct validation message for short passwords (_Hannah Wolfe_)
* Client & Server side validation for posts per page (_Hannah Wolfe_)
* 500 Series Error Handling & Stack Traces (_Christopher Giffard_)
* New Tag in fixture breaks Tag tests (_Hannah Wolfe_)
* Minor updates to Readme (_Hannah Wolfe_)
* Version bump ready for release (_Hannah Wolfe_)
* Removing Temporary importer (_Hannah Wolfe_)
* New default user image (_John O'Nolan_)

## Release 0.3.0-5

No changes were made in this build.


## Release 0.3.0-4

No changes were made in this build.


## Release 0.3.0-3

No changes were made in this build.

